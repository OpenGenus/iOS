//
//  ViewController.swift
//  FireBaseLogin
//
//  Created by Sai Balaji on 13/03/21.
//

import UIKit
import Firebase

class LoginVC: UIViewController {

    @IBOutlet weak var emailtxtbox: CustomTextField!
    @IBOutlet weak var passwordtxtbox: CustomTextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func signupbtnclicked(_ sender: Any) {
        
       
        performSegue(withIdentifier: "segue", sender: self)
        
        
    }
    
    @IBAction func signinbtnPressed(_ sender: Any) {
        if let email = emailtxtbox.text , let password = passwordtxtbox.text
        {
            Auth.auth().signIn(withEmail: email, password:password) { (authresultdata, error) in
                if let err = error
                {
                    self.showAlert(message: err.localizedDescription)
                }
                else
                {
                    self.showAlert(message: "Success")
                }
            }
        }
    }
    
    
    
    func showAlert(message: String)
    {
        let ac = UIAlertController(title: "Info", message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        
        present(ac, animated: true, completion: nil)
    }
    
}

