//
//  SignUpVC.swift
//  FireBaseLogin
//
//  Created by Sai Balaji on 13/03/21.
//

import UIKit
import Firebase

class SignUpVC: UIViewController {

    
    
    @IBOutlet weak var emailtxtbox: CustomTextField!
    @IBOutlet weak var passwordtxtbox: CustomTextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func SignUpBtnPressed(_ sender: Any) {
        
        
        if let email = emailtxtbox.text ,let password = passwordtxtbox.text
        {
            Auth.auth().createUser(withEmail: email, password: password) { (resultdata, error) in
                if let err = error
                {
                    self.showAlert(message: err.localizedDescription)
                }
                else
                {
                    self.showAlert(message: "Account Created")
                    
                }
            }
        }
        
        
        
        
    }
    @IBAction func backbtnpressed(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func showAlert(message: String)
    {
        let ac = UIAlertController(title: "Info", message: message, preferredStyle: .alert)
        ac.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        
        present(ac, animated: true, completion: nil)
    }
    

}
